import java.util.Scanner;

/**
 * EA1. Manipulación de Vectores en Java
 *
 * Programa que permite:
 * 1) Crear y llenar un vector de 15 enteros (validando rango 10-100).
 * 2) Buscar un valor dentro del vector.
 * 3) Determinar el mayor y el menor valor del vector.
 * 4) Identificar los múltiplos de un número X ingresado por el usuario.
 * 5) Calcular la suma total de los valores del vector.
 * 6) Crear un nuevo vector con los números por encima del promedio.
 */
public class Main {

    // Tamaño fijo del vector según las instrucciones de la actividad
    static final int TAMANIO = 15;
    static final int LIMITE_INFERIOR = 10;
    static final int LIMITE_SUPERIOR = 100;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // 1) Crear y llenar el vector con validación de rango
        int[] vector = llenarVector(sc);
        mostrarVector(vector, "Vector ingresado");

        // 2) y 3) Buscar un valor, y de paso obtener el mayor y el menor
        buscarValor(sc, vector);
        mostrarMayorYMenor(vector);

        // 4) Identificar múltiplos de un número X
        identificarMultiplos(sc, vector);

        // 5) Calcular la suma total
        int suma = calcularSuma(vector);
        System.out.println("\nLa suma total de los valores del vector es: " + suma);

        // 6) Crear un nuevo vector con los números por encima del promedio
        crearVectorSobrePromedio(vector, suma);

        sc.close();
    }

    /**
     * Solicita al usuario los 15 valores del vector, validando que cada uno
     * esté dentro del rango [LIMITE_INFERIOR, LIMITE_SUPERIOR]. Si el valor
     * ingresado está fuera de rango, se informa y se vuelve a pedir el dato
     * para esa misma posición.
     */
    static int[] llenarVector(Scanner sc) {
        int[] vector = new int[TAMANIO];

        System.out.println("=== Llenado del vector (" + TAMANIO + " números entre "
                + LIMITE_INFERIOR + " y " + LIMITE_SUPERIOR + ") ===");

        for (int i = 0; i < TAMANIO; i++) {
            boolean valorValido = false;

            while (!valorValido) {
                System.out.print("Ingrese el valor #" + (i + 1) + ": ");

                if (sc.hasNextInt()) {
                    int numero = sc.nextInt();

                    if (numero >= LIMITE_INFERIOR && numero <= LIMITE_SUPERIOR) {
                        vector[i] = numero;
                        valorValido = true;
                    } else {
                        System.out.println("El número " + numero + " está fuera del rango ("
                                + LIMITE_INFERIOR + "-" + LIMITE_SUPERIOR + "). Intente de nuevo.");
                    }
                } else {
                    // Descarta la entrada no numérica para evitar un ciclo infinito
                    System.out.println("Entrada inválida. Debe ingresar un número entero.");
                    sc.next();
                }
            }
        }

        return vector;
    }

    /** Muestra el contenido del vector en la consola con un título. */
    static void mostrarVector(int[] vector, String titulo) {
        System.out.println("\n" + titulo + ":");
        StringBuilder sb = new StringBuilder("[ ");
        for (int valor : vector) {
            sb.append(valor).append(" ");
        }
        sb.append("]");
        System.out.println(sb);
    }

    /**
     * Solicita un número al usuario y lo busca dentro del vector.
     * Muestra la posición si lo encuentra, o un mensaje si no está.
     */
    static void buscarValor(Scanner sc, int[] vector) {
        System.out.print("\nIngrese un número para buscar en el vector: ");
        int buscado = sc.nextInt();

        int posicion = -1;
        for (int i = 0; i < vector.length; i++) {
            if (vector[i] == buscado) {
                posicion = i;
                break; // ya lo encontramos, no es necesario seguir recorriendo
            }
        }

        if (posicion != -1) {
            System.out.println("El número " + buscado + " se encontró en la posición " + posicion + ".");
        } else {
            System.out.println("El número " + buscado + " no está en el vector.");
        }
    }

    /** Recorre el vector para determinar y mostrar el mayor y el menor valor. */
    static void mostrarMayorYMenor(int[] vector) {
        int mayor = vector[0];
        int menor = vector[0];

        for (int valor : vector) {
            if (valor > mayor) {
                mayor = valor;
            }
            if (valor < menor) {
                menor = valor;
            }
        }

        System.out.println("\nEl número mayor del vector es: " + mayor);
        System.out.println("El número menor del vector es: " + menor);
    }

    /**
     * Solicita un número X al usuario y muestra todos los elementos del
     * vector que son múltiplos de X. Si no hay múltiplos, informa que no
     * hay ninguno.
     */
    static void identificarMultiplos(Scanner sc, int[] vector) {
        System.out.print("\nIngrese un número X para buscar sus múltiplos en el vector: ");
        int x = sc.nextInt();

        System.out.println("Múltiplos de " + x + " en el vector:");
        boolean hayMultiplos = false;

        if (x != 0) {
            for (int valor : vector) {
                if (valor % x == 0) {
                    System.out.println("- " + valor);
                    hayMultiplos = true;
                }
            }
        }

        if (!hayMultiplos) {
            System.out.println("No hay múltiplos de " + x + " en el vector.");
        }
    }

    /** Recorre el vector y devuelve la suma total de sus valores. */
    static int calcularSuma(int[] vector) {
        int suma = 0;
        for (int valor : vector) {
            suma += valor;
        }
        return suma;
    }

    /**
     * Calcula el promedio del vector original y crea un nuevo vector que
     * contiene únicamente los valores por encima de dicho promedio.
     */
    static void crearVectorSobrePromedio(int[] vector, int suma) {
        double promedio = (double) suma / vector.length;
        System.out.printf("%nEl promedio de los valores es: %.2f%n", promedio);

        // Primero se cuenta cuántos números están por encima del promedio
        // para poder crear el nuevo vector con el tamaño exacto.
        int cantidad = 0;
        for (int valor : vector) {
            if (valor > promedio) {
                cantidad++;
            }
        }

        if (cantidad == 0) {
            System.out.println("No hay números por encima del promedio.");
            return;
        }

        int[] sobrePromedio = new int[cantidad];
        int indice = 0;
        for (int valor : vector) {
            if (valor > promedio) {
                sobrePromedio[indice] = valor;
                indice++;
            }
        }

        mostrarVector(sobrePromedio, "Números por encima del promedio");
        System.out.println("Cantidad de números por encima del promedio: " + cantidad);
    }
}
